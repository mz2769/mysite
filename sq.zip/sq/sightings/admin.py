from django.contrib import admin

from .models import Squirrel
admin.site.register(Squirrel)
