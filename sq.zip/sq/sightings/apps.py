from django.apps import AppConfig


class SquirrelConfig(AppConfig):
    name = 'sightings'
